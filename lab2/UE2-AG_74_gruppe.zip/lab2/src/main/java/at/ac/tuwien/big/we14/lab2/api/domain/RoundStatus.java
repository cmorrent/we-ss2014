package at.ac.tuwien.big.we14.lab2.api.domain;

/**
 * Created by willi on 4/9/14.
 */
public enum RoundStatus {
    open,
    closed_player1Won,
    closed_player2Won,
    closed_tie
}
