package at.ac.tuwien.big.we14.lab2.api.inputLogic.Event;

/**
 * Created by willi on 4/19/14.
 */
public enum EventType {
    idle,
    start,
    answer,
    gotoNextQuestionFromRoundComplete,
    gotoFinish,
    restart,
}
