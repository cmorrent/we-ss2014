package at.ac.tuwien.big.we14.lab2.api.domain;

/**
 * Created by willi on 4/9/14.
 */
public enum AnswerStatus {
    open,
    answered_correct,
    answered_failed,
}
