package at.ac.tuwien.big.we14.lab2.api.service;

import java.util.List;

/**
 * Created by Lukas on 26.04.2014.
 */
public interface AnswerService {

        public void answerQuestion(List<Integer> choices);

}
